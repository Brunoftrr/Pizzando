import java.sql.*;

public class Conexao {
    public static Connection conectar() throws Exception {
        return DriverManager.getConnection("jdbc:postgresql://localhost:5432/BancoBase", "postgres", "postgres");
    }
}
