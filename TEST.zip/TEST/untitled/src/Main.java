import java.sql.*;

public class Main {
    public static void main(String[] args) {
        Connection conexao = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conexao = Conexao.conectar();
            System.out.println("Conectado ao banco!");
            stmt = conexao.createStatement();
            rs = stmt.executeQuery("SELECT * FROM USUARIO");

            while (rs.next()) {
                System.out.println(rs.getString(1));
                System.out.println(rs.getString(2));
                System.out.println(rs.getString(3));
            }
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}